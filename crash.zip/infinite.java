import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.Random;
import javax.swing.JOptionPane;
public class infinite {

    public static void main(String[] args) {
    	 boolean g = false;
        int result = JOptionPane.showConfirmDialog(
                null, // Parent component (null for centering on screen)
                "This Will Crash Your Computer. Proceed?", // Message to display
                "Confirmation", // Title of the dialog
                JOptionPane.YES_NO_OPTION // Type of options (Yes/No buttons)
        );
       
        // Process the user's choice 

        // Process the user's choice
        if (result == JOptionPane.YES_OPTION) {
            System.out.println("User chose Yes. Proceeding with the action.");
            g = true;
            // Your code to execute when the user confirms
        } else if (result == JOptionPane.NO_OPTION) {
            System.out.println("User chose No. Canceling the action.");
            // Your code to execute when the user cancels
        } else if (result == JOptionPane.CLOSED_OPTION) {
            System.out.println("User closed the dialog without making a choice.");
            // Handle dialog closure (optional)
        }

        	while (g == true) {
                // Create a new JFrame (your window)
                JFrame frame = new JFrame("Random Window");
                frame.setSize(300, 300); // Set initial size

                // Get screen dimensions
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                int screenWidth = screenSize.width;
                int screenHeight = screenSize.height;

                // Create a Random object for generating random numbers
                Random random = new Random();

                // Calculate random coordinates within screen boundaries
                // Ensure the window fits within the screen, considering its size
                int x = random.nextInt();
                int y = random.nextInt();

                // Set the window's location
                frame.setLocation(x, y);

                // Make the window visible
                frame.setVisible(true);

    	

        // Optional: Close the application when the window is closed
         
 
        
   
  }
    }
}
   

      
    
     

